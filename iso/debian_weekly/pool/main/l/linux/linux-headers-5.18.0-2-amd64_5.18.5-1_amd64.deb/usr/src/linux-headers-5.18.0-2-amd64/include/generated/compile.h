/* This file is auto generated, version 1 */
/* SMP PREEMPT_DYNAMIC */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#1 SMP PREEMPT_DYNAMIC Debian 5.18.5-1 (2022-06-16)"
#define LINUX_COMPILE_BY "debian-kernel"
#define LINUX_COMPILE_HOST "lists.debian.org"
#define LINUX_COMPILER "gcc-11 (Debian 11.3.0-3) 11.3.0, GNU ld (GNU Binutils for Debian) 2.38.50.20220615"
